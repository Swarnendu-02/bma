<div class="menu-wrap">
    <div class="ft-menu-cell clr-1">
        <h5 class="ft-head">Our Organizations</h5>
        <ul class="ft-menu">
            <li><a href="aboutus.php">About Us</a></li>
            <li><a>Our History</a></li>
            <li><a href="developmentofjjs.php">Development Of JJS</a></li>
            <li><a href="ourphilosophy.php">Our Philosophy</a></li>
            <li><a href="integralhumanism.php">Integral Humanism</a></li>
            <li><a href="antyodaya.php">Antyodaya</a></li>
            <li><a href="constitution.php">Constitution</a></li>
        </ul>
    </div>
    <div class="ft-menu-cell clr-2">
        <h5 class="ft-head">Documents</h5>
        <ul class="ft-menu">
            <li><a href="executive-resolution.php">Executive Resolution</a></li>
            <li><a href="unionbudget.php">Union Budget 2022-2023</a></li>
            <li><a href="manifesto.php">Manifesto</a></li>
            <li><a href="elctionformate.php">Election Formate</a></li>
        </ul>
    </div>
    <div class="ft-menu-cell clr-3">
        <h5 class="ft-head">Our Leadership</h5>
        <ul class="ft-menu">
            <li><a href="presidentdetails.php">Leader 1</a></li>
            <li><a href="presidentdetails.php">Leader 2</a></li>
            <li><a href="presidentdetails.php">Leader 3</a></li>
            <li><a href="presidentdetails.php">Leader 4</a></li>
            <li><a href="presidentdetails.php">Leader 5</a></li>
        </ul>


    </div>
    <div class="ft-menu-cell clr-4">
        <h5 class="ft-head">Our Departments</h5>
        <ul class="ft-menu">
            <li><a href="department.php">Departmnt 1</a></li>
            <li><a href="department.php">Departmnt 2</a></li>
            <li><a href="department.php">Departmnt 3</a></li>
            <li><a href="department.php">Departmnt 4</a></li>
            <li><a href="department.php">Departmnt 5</a></li>
            <li><a href="department.php">Departmnt 6</a></li>
            <li><a href="department.php">Departmnt 7</a></li>
            <li><a href="department.php">Departmnt 8</a></li>
        </ul>
    </div>


</div>
<div class="ft-menu-cell">
    <div class="ft-btn-menu">
        <a>Partners</a>
        <a href="media.php" class="clr-2">Media</a>
        <a>Donation</a>
        <a>Certifications</a>
        <a href="interviews.php">Interviews</a>
        <a href="upcomingevents.php">Upcoming Events</a>
        <a>Upcoming Symposium</a>
        <a>Latest news</a>
    </div>
</div>