<div class="container-fluid " style="margin-top: -90px;" overflow: hidden;>
    <div class="container position-relative">
        <div class="row" style="align-items: end;">
            <div class="col-4 py-5 pr-5 testi-left position-relative" style="background: #01d6a3">
                <div class="col-12">
                    <h6 class="">CLIENTS</h6>
                    <h2 class="font-weight-bold mb-4">Happy with Customers & Clients</h2>
                    <p class="mb-4" style="word-break: break-all; ">If you need any medical help we are available for you. Lorem ipsum dolor sit amet, sectetur adipiscing elit, sed do eiusmod tempor the incididunt ut labore et dolore.</p>
                </div>
            </div>
            <div class="col-md-8 p-5 testi-right position-relative pr-0" style="background-color: #033b4a;     margin-top: 60px;     z-index: 1;">
                <div class=" owl-carousel owl-theme px-3">
                    <div class="item" style="z-index: 9;">
                        <p class="display-6 text-center text-white"><i class="fas fa-quote-left"></i></p>
                        <p class="text-center my-4 text-white">A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.</p>
                        <p class="text-center my-3 text-white"><img src="images/demo.jpg" class="rounded-circle" style="width: 40px; height:40px; object-fit:cover; margin: auto;
    display: initial;"></p>
                        <p class="text-center mb-0 text-white">name</p>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <script>
        $('.owl-carousel').owlCarousel({
            autoplay: true,
            autoplayTimeout: 5000,
            autoplayHoverPause: true,
            loop: true,
            lazyLoad: true,
            animateOut: 'slideOutDown',
            animateIn: 'flipInX',
            items: 1,
            margin: 30,
            stagePadding: 30,
            smartSpeed: 450,
            nav: false,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 1
                },
                1000: {
                    items: 1
                }
            }
        })
    </script>
</div>