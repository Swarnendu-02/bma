<header>
    <div class="container">
        <div class="logo-cell">
            <img src="images/logo.png">
        </div>
        <div class="nav-wrap">
            <div class="nav-cell d-flex align-items-center">
                <a class="d-none d-sm-block">
                    Join JJS
                </a>
                <a class="d-none d-sm-block">
                    Become A Member
                </a>
                <a class="d-none d-sm-block">
                    Donation
                </a>
                <button onclick="$('.slide-menu').slideDown();" class="menu-btn">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </div>
    </div>
</header>
<div class="slide-menu">
		<div class="container">
			<div class="d-flex align-items-center justify-content-between pb-3 pb-md-5 border-bottom">
				<h3 class="main-heading">Navigation</h3>
				<button onclick="$('.slide-menu').slideUp();" class="nav-cls-btn">
					<i class="fas fa-times"></i>
				</button>
			</div>
            <? include("menu-wrap.php"); ?>
           
		</div>
	</div>