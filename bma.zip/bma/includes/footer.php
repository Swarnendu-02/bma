<div class="section footer" id="section7">
<div class="container">
    <div class="d-md-flex align-items-center justify-content-between pb-2 pb-md-5 border-bottom">
        <h3 class="main-heading mb-3 mb-md-0">SITEMAP</h3>
        <div class="sub-frm-cell">
            <input type="text" placeholder="Enter Mobile Number">
            <button>Subscribe</button>
        </div>
    </div>
    <? include("menu-wrap.php"); ?>
    <div class="d-md-flex align-items-center justify-content-between mt-2 mt-md-5 pt-2 pt-md-5 border-top ">
        <p class="mb-0 text-white" style="font-size: 16px;color: #d9d9d9 !important;">Copyright 2022 JJP | Designed by <a href="https://www.encoders.co.in/" target="_blank">Encoders</a></p>
        <p class="mb-0" style="color: #d9d9d9 !important; font-size:20px;">Follow Us On: <a style=" margin-right:10px;margin-left:10px;"><i class="fab fa-facebook"></i></a> <a margin-right:10px;"><i class="fab fa-instagram"></i></a> <a><i class="fab fa-twitter"></i></a></p>
    </div>
</div>
</div>